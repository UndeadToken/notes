#bash statements for chapter 08
psql -U forum forumdb

psql forumdb


