### Chapter7
psql -U forum forumdb
service postgresql reload
psql -U forum forumdb
psql forumdb
psql -U forum forumdb
