\c forumdb
insert into forum.users(username,gecos,email) values ('enrico',1,'enrico.pirozzi@packtpub.xyz');
