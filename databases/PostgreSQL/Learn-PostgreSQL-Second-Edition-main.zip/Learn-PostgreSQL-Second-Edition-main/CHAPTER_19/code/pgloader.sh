 pgloader mysql://root:LearnPostgreSQL@mariadb-source/forumdb pgsql://postgres@127.0.0.1/forumdb
