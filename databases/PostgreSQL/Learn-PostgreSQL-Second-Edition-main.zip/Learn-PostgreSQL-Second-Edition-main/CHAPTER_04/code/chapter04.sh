cd docker-images/standalone/
sudo docker-compose build
sudo docker-compose up -d
sudo docker-compose logs
sudo docker-compose ps
sudo docker exec -it standalone_learn_postgresql_1 /bin/bash
su - postgres
psql
su - postgres
psql
psql -U myforum myforumdb
psql template1
psql -U forum forumdb2
psql -U forum forumdb
cd /var/lib/postgresql/16/main/
cd /postgres/16/data
ls -l
cd base
ls -l
psql -U forum forumdb
cd 16386/
pwd
cd /var/lib/postgresql/16/main/base/16386
cd /postgres/16/data/base/16386
ls -l | grep 16389
