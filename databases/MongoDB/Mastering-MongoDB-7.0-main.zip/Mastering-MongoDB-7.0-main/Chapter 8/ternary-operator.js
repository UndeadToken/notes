// ternary operator

function getPrice(isMember) {
    return isMember ? '$15.00' : '$30.00';
    }