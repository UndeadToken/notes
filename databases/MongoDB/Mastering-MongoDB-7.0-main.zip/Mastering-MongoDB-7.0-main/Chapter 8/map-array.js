// map over a JS array

const array1 = [1, 2, 3, 5]

// apply a function to each array member
const map1 = array1.map(x => x ** 3)

// output
[1, 8, 27, 125]